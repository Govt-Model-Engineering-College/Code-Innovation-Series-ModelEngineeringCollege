# okcomputer

A website which checks wheather a transaction is fraudulent

# Installation

*Fork and Clone the Repo
```
https://github.com/[your_name]/okcomputer.git
```
*Install All Requirements

*Run : 
