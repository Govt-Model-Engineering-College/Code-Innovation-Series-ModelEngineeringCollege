from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse, reverse_lazy
# Create your models here.

class UserProfileInfo(models.Model):

    user = models.OneToOneField(User, on_delete= models.CASCADE)  #this class is an extension to the inbuilt User Model and this line says that the user object is Primary Key
    #additional objects besides the User model
    profile_pic = models.ImageField(blank= True , upload_to ='profile_pics')

    def __str__(self):
        return self.user.username

PAYMENT_METHODS = [('cashout', 'CASH OUT'),('transfer','TRANSFER')]

class Transaction(models.Model):

    step = models.IntegerField(default=0,verbose_name='maps a unit of time in the real world. In this case 1 step is 1 hour of time. Total steps 744 (30 days simulation).')
    amount = models.FloatField(default=0,verbose_name='Transaction Amount')
    nameOrig = models.CharField(max_length=200,verbose_name='Sender')
    old_balance_org = models.FloatField(default=0,verbose_name='Initial Balance of Sender Before Transaction')
    new_balance_org = models.FloatField(default=0,verbose_name='New Balance of Sender After Transaction')
    nameDest = models.CharField(max_length=200,verbose_name='Reciever')
    old_balance_dest = models.FloatField(default=0,verbose_name='Initial Balance of Reciever Before Transaction')
    new_balance_dest = models.FloatField(default=0,verbose_name='Final Balance of Reciever After Transaction')
    transaction_type = models.CharField(max_length = 20,choices=PAYMENT_METHODS,default='cashout',verbose_name='Transaction Type')
    user = models.ForeignKey(User, on_delete=models.CASCADE,default=1)
    testing = models.CharField(max_length=200,default='null')
    

    def __str__(self):
        return str(self.amount)
    def get_absolute_url(self):
        return reverse('fraud:result')
    
