package com.cloud69.edu_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
