import 'dart:convert';

import 'package:edu_app/main.dart';
import 'package:flutter/material.dart';
// import 'package:youtube_player_iframe/youtube_player_iframe.dart';

class Chapter {
  Chapter({this.courseId, this.grade, this.chapterName,this.playListLink});
  final int courseId;
  final int grade;
  final String chapterName;
  final String playListLink;
}
List<Chapter> AllChapters = [
  new Chapter(courseId: 0,grade: 3,chapterName: 'Lesson 1', playListLink: 'link'),
  new Chapter(courseId: 0,grade: 3,chapterName: 'Lesson 2', playListLink: 'link'),
  new Chapter(courseId: 0,grade: 3,chapterName: 'Lesson 3', playListLink: 'link'),

  new Chapter(courseId: 0,grade: 4,chapterName: 'Lesson 1', playListLink: 'link'),
  new Chapter(courseId: 0,grade: 4,chapterName: 'Lesson 2', playListLink: 'link'),
  new Chapter(courseId: 0,grade: 4,chapterName: 'Lesson 3', playListLink: 'link'),
];
class Course {
  final String courseName;
  final Image courseImage;
  const Course(this.courseName, this.courseImage);

}
Course findCourse(int index)
{
  String name = " ";
  Image image;
  switch(index)
  {
    case 0: name = "Mathematics";
            image = Image.asset('assets/img/equation.png');
            break;
    case 1: name = "EVS";
            image = Image.asset('assets/img/earth.png');
            break;
    case 2: name = "English";
            image = Image.asset('assets/img/reception.png');
            break;
    case 3: name = "Computer";
            image = Image.asset('assets/img/computer.png');
            break;
    case 4: name = "Computer";
            image = Image.asset('assets/img/computer.png');
            break;
    case 5: name = "Computer";
            image = Image.asset('assets/img/computer.png');
            break;
  }
  return Course(name,image);
}

class HomePage extends StatefulWidget {

  @override
  State<StatefulWidget> createState() {
    return HomePageState();
  }
}

class HomePageState extends State<HomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text("SmartLearn"),
      ),
      body: ListView(
        padding: EdgeInsets.all(5),
        children:<Widget>[
          Padding(
              padding: EdgeInsets.fromLTRB(0,20,0,20),
              child: Container(
                height: 280,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  image: DecorationImage(image: AssetImage('assets/img/back.jpg'),fit: BoxFit.contain,alignment: Alignment.bottomCenter),
                ),
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 10,horizontal: 5),
                  child:Text(
                    "MY COURSES",
                    style: Theme.of(context).textTheme.headline4.copyWith(color: Colors.black,),
                    textAlign: TextAlign.center,
                  ),
                ),
              )
          ),
          Expanded(
            child: GridView.count(
              shrinkWrap: true,
              primary: true,
              scrollDirection: Axis.vertical,
              physics: NeverScrollableScrollPhysics(),
              // Create a grid with 2 columns. If you change the scrollDirection to
              // horizontal, this produces 2 rows.
              crossAxisCount: 2,
              // Generate 100 widgets that display their index in the List.
              children: List.generate(6, (index) {
                return Padding(
                  padding: EdgeInsets.all(10),
                  child:Container(
                    width: double.infinity,

                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: Colors.grey),
                        color: Colors.white,
                        boxShadow: [new BoxShadow(
                          color:  Colors.grey.withOpacity(0.5),
                          offset: Offset(0,8),
                          blurRadius: 5.0,
                          spreadRadius: 0,
                        ),]
                    ),
                    child: Center(
                      child:Padding(
                        padding: EdgeInsets.fromLTRB(0, 20, 0, 10),
                        child:new GestureDetector(
                          onTap: (){
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => GradeSelectionScreen(courseId: index,)),
                            );
                          },
                          child:Column(
                            children:[
                              Expanded(child:findCourse(index).courseImage),
                              Container(

                                margin: EdgeInsets.symmetric(vertical: 10,horizontal: 5),
                                child: Text(
                                  findCourse(index).courseName,
                                  style: Theme.of(context).textTheme.headline5.copyWith(fontSize: 18),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ]
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),

        ]
      ),


      drawer: Drawer(
        // Add a ListView to the drawer. This ensures the user can scroll
        // through the options in the drawer if there isn't enough vertical
        // space to fit everything.
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: <Widget>[
            Container(
              height: 100,
              child: DrawerHeader(
                child: Text('Username'),
                decoration: BoxDecoration(
                  color: Colors.green,
                ),
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  border: Border(bottom:BorderSide(color: Colors.grey))
              ),
              child:ListTile(
                title: Text('My progress'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  border: Border(bottom:BorderSide(color: Colors.grey))
              ),
              child:ListTile(
                title: Text('My Courses'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  border: Border(bottom:BorderSide(color: Colors.grey))
              ),
              child:ListTile(
                title: Text('Settings'),
                onTap: () {
                  // Update the state of the app
                  // ...
                  // Then close the drawer
                  Navigator.pop(context);
                },
              ),
            ),
            Container(
              decoration: BoxDecoration(
                  border: Border(bottom:BorderSide(color: Colors.grey))
              ),
              child:ListTile(
                title: Text('Log Out'),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LogInPage()),
                  );
                },
              ),
            ),

          ],
        ),
      ),
    );
  }
}
class GradeSelectionScreen extends StatelessWidget {
  final int courseId;
  GradeSelectionScreen({Key key, @required this.courseId}) : super(key: key);
  @override
  Widget build (BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          title: new Text(findCourse(courseId).courseName),
        ),
        body: ListView(
          children: List.generate(6, (index) {
            int grade = index+3;
            return new GestureDetector(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ChapterSelectionScreen(courseId: courseId,grade: grade,)),
                );
              },
              child:Container(
                margin: EdgeInsets.symmetric(horizontal: 5,vertical: 10),
                width: double.infinity,
                height: 90,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey[400]),
                    color: Colors.white,
                    boxShadow: [new BoxShadow(
                      color:  Colors.grey.withOpacity(0.3),
                      offset: Offset(0,2),
                      blurRadius: 3.0,
                      spreadRadius: 0,
                    ),]
                ),
                child: Row(
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(vertical:10,horizontal: 10),
                      child: Image.asset('assets/img/book.png',),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      child: Text('Grade $grade',textScaleFactor: 1.5,),
                    )
                  ],
                ),
              ),
            );
          }),
        )
    );
  }
}

class ChapterSelectionScreen extends StatelessWidget {
  final int courseId;
  final int grade;
  ChapterSelectionScreen({Key key, @required this.courseId,@required this.grade}) : super(key: key);
  @override
  Widget build (BuildContext context) {
    var chapterArray =AllChapters.where((element) => element.courseId == courseId && element.grade == grade).toList();
    return new Scaffold(
        appBar: new AppBar(
          title: new Text(findCourse(courseId).courseName+': Grade '+grade.toString()),
        ),
        body: ListView(
          children: List.generate(chapterArray.length, (index) {
            return new GestureDetector(
              onTap: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MaterialScreen(courseId: courseId,grade: grade,chapterIndex: index,)),
                );
              },
              child:Container(
                margin: EdgeInsets.symmetric(horizontal: 5,vertical: 10),
                width: double.infinity,
                height: 90,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.grey[400]),
                    color: Colors.white,
                    boxShadow: [new BoxShadow(
                      color:  Colors.grey.withOpacity(0.3),
                      offset: Offset(0,2),
                      blurRadius: 3.0,
                      spreadRadius: 0,
                    ),]
                ),
                child: Row(
                  children: [
                    Container(
                      margin: EdgeInsets.symmetric(vertical:10,horizontal: 10),
                      child: Image.asset('assets/img/book.png',),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      child: Text(chapterArray[index].chapterName,textScaleFactor: 1.5,),
                    )
                  ],
                ),
              ),
            );
          }),
        )
    );
  }
}

class MaterialScreen extends StatelessWidget {
  final int courseId;
  final int grade;
  final int chapterIndex;
  MaterialScreen({Key key, @required this.courseId,@required this.grade,@required this.chapterIndex}) : super(key: key);
  @override
  Widget build (BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          title: new Text(AllChapters.where((element) => element.courseId == courseId && element.grade == grade).toList()[chapterIndex].chapterName),
        ),
        body: ListView(
          children: [

          ],
        )
    );
  }
}

